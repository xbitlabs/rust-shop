package me.insidezhou.southernquiet.file.web.exception;

public class NotFoundException extends RuntimeException {
}
