package test.broadcasting;

public class ChildBroadcastingDone extends BroadcastingDone {}

