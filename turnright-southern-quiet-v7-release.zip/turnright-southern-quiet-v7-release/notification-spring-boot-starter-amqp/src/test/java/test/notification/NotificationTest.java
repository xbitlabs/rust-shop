//package test.notification;
//
//import me.insidezhou.southernquiet.amqp.rabbit.DelayedMessage;
//import me.insidezhou.southernquiet.debounce.Debounce;
//import me.insidezhou.southernquiet.logging.SouthernQuietLogger;
//import me.insidezhou.southernquiet.logging.SouthernQuietLoggerFactory;
//import me.insidezhou.southernquiet.notification.AmqpNotificationAutoConfiguration;
//import me.insidezhou.southernquiet.notification.NotificationListener;
//import me.insidezhou.southernquiet.notification.Qos;
//import me.insidezhou.southernquiet.notification.driver.AmqpNotificationPublisher;
//import org.junit.Assert;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.amqp.core.QueueInformation;
//import org.springframework.amqp.rabbit.core.RabbitAdmin;
//import org.springframework.amqp.rabbit.core.RabbitTemplate;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.SpringBootConfiguration;
//import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.context.annotation.Bean;
//import org.springframework.test.context.junit4.SpringRunner;
//
//import java.io.Serializable;
//import java.time.Duration;
//import java.time.Instant;
//import java.util.UUID;
//
//@RunWith(SpringRunner.class)
//@SpringBootTest
//public class NotificationTest {
//    private final static SouthernQuietLogger log = SouthernQuietLoggerFactory.getLogger(NotificationTest.class);
//
//    @SpringBootConfiguration
//    @EnableAutoConfiguration
//    public static class Config {
//        @Bean
//        public NotificationTest.Listener listener() {
//            return new NotificationTest.Listener();
//        }
//    }
//
//    @Autowired
//    private AmqpNotificationPublisher<Serializable> notificationPublisher;
//
//    @Autowired
//    private AmqpNotificationAutoConfiguration.Properties properties;
//
//    @Test
//    public void dummy() {
//        notificationPublisher.publish(new StandardNotification());
//        notificationPublisher.publish(new StandardNotification(), "a");
//    }
//
//    @Test
//    public void qos() {
//        notificationPublisher.publish(new ConcurrentNotification());
//        notificationPublisher.publish(new ConcurrentNotification(), "a");
//    }
//
//    @Test
//    public void delay() {
//        notificationPublisher.publish(new DelayedNotification());
//        notificationPublisher.publish(new DelayedNotification(), 10000);
//
//        notificationPublisher.publish(new DelayedNotification(), "b");
//        notificationPublisher.publish(new DelayedNotification(), 10000,"b");
//    }
//
//    @Test
//    public void queueDeclared() {
//        String deadRouting = properties.getNamePrefix() + "DEAD." + StandardNotification.class.getSimpleName() + "#a";
//        RabbitTemplate rabbitTemplate = notificationPublisher.getVirtualHostRabbitTemplateMap().get("a");
//        RabbitAdmin rabbitAdmin = notificationPublisher.getRabbitAdminByVirtualHost(rabbitTemplate.getConnectionFactory().getVirtualHost());
//
//        QueueInformation deadQueue = rabbitAdmin.getQueueInfo(deadRouting);
//        Assert.assertNotNull(deadQueue);
//
//        deadRouting = properties.getNamePrefix() + "DEAD." + StandardNotification.class.getSimpleName() + "#b";
//        deadQueue = notificationPublisher.getBaseRabbitAdmin().getQueueInfo(deadRouting);
//        Assert.assertNotNull(deadQueue);
//    }
//
//    @SuppressWarnings("unused")
//    public static class Listener {
//        @NotificationListener(notification = StandardNotification.class, name = "a", virtualHosts = "a")
//        @NotificationListener(notification = StandardNotification.class, name = "b")
//        @NotificationListener(notification = StandardNotification.class, name = "c")
//        @NotificationListener(notification = StandardNotification.class, name = "d", virtualHosts = "a")
//        @Debounce
//        public void standard(StandardNotification notification, NotificationListener listener) {
//            log.message("使用监听器接到通知")
//                .context("listenerName", listener.name())
//                .context("id", notification.getId())
//                .info();
//        }
//
//        @NotificationListener(notification = StandardNotification.class, name = "c")
//        @NotificationListener(notification = StandardNotification.class, name = "d", virtualHosts = "a")
//        public void exception(StandardNotification notification, NotificationListener listener) {
//            throw new RuntimeException("在通知中抛出异常通知：listener=" + listener.name() + ", notification=" + notification.getId());
//        }
//
//        @NotificationListener(notification = ConcurrentNotification.class, name = "e", qos = @Qos(prefetchCount = 10, prefetchSize = 2))
//        @NotificationListener(notification = ConcurrentNotification.class, name = "f", virtualHosts = "a", qos = @Qos(prefetchCount = 10, prefetchSize = 2))
//        public void qos(ConcurrentNotification notification, NotificationListener listener) {
//            log.message("使用监听器接到通知")
//                    .context("listenerName", listener.name())
//                    .context("id", notification.getId())
//                    .info();
//        }
//
//        @NotificationListener(notification = DelayedNotification.class)
//        @NotificationListener(notification = DelayedNotification.class, virtualHosts = "b")
//        public void delay(DelayedNotification notification, NotificationListener listener, DelayedMessage delayedAnnotation) {
//            log.message("使用监听器接到延迟通知")
//                .context("listenerName", listener.name())
//                .context("delay", delayedAnnotation)
//                .context("publishedAt", notification.publishedAt)
//                .context("duration", Duration.between(notification.publishedAt, Instant.now()))
//                .info();
//        }
//
//        public static final int concurrency = 2;
//
//        @NotificationListener(notification = ConcurrentNotification.class, concurrency = Listener.concurrency)
//        @NotificationListener(notification = ConcurrentNotification.class, concurrency = Listener.concurrency, virtualHosts = {"a", "b"})
//        public void concurrent(ConcurrentNotification notification, NotificationListener listener) {
//
//            log.message("使用并发监听器接到通知")
//                .context("listenerName", listener.name())
//                .context("listenerConcurrent", listener.concurrency())
//                .context("notificationId", notification.getId())
//                .context("currentThreadName", Thread.currentThread().getName())
//                .info();
//        }
//    }
//
//    public static class StandardNotification implements Serializable {
//        private static final long serialVersionUID = 5398319634237379027L;
//        private UUID id = UUID.randomUUID();
//
//        public UUID getId() {
//            return id;
//        }
//
//        public void setId(UUID id) {
//            this.id = id;
//        }
//    }
//
//    @DelayedMessage(3000)
//    public static class DelayedNotification implements Serializable {
//        private static final long serialVersionUID = 6146809100599344867L;
//        private Instant publishedAt = Instant.now();
//
//        public Instant getPublishedAt() {
//            return publishedAt;
//        }
//
//        public void setPublishedAt(Instant publishedAt) {
//            this.publishedAt = publishedAt;
//        }
//    }
//
//    public static class ConcurrentNotification implements Serializable {
//        private static final long serialVersionUID = -2099926071771530861L;
//        private UUID id = UUID.randomUUID();
//
//        public UUID getId() {
//            return id;
//        }
//
//        public void setId(UUID id) {
//            this.id = id;
//        }
//    }
//}
