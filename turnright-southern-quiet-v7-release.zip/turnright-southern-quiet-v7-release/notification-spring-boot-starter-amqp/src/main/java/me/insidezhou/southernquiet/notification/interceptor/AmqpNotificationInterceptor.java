package me.insidezhou.southernquiet.notification.interceptor;

import me.insidezhou.southernquiet.notification.correlation.NotificationBody;
import org.springframework.amqp.rabbit.connection.CorrelationData;

/**
 * rabbit 通知拦截器接口
 *
 * @author maurice.chen
 */
public interface AmqpNotificationInterceptor {

    /**
     * 是否支持消息通知体
     *
     * @param notificationBody 消息通知体
     *
     * @return true 是，否则 false
     */
    boolean isSupport(NotificationBody notificationBody);

    /**
     * 创建相关数据
     *
     * @param notificationBody 消息通知体
     *
     * @return 相关数据
     */
    CorrelationData createCorrelationData(NotificationBody notificationBody);

    /**
     * 消息发送成功时，触发此方法。
     *
     * @param notificationBody 消息通知体
     */
    default void invokeSuccess(NotificationBody notificationBody) {

    }

    /**
     * 消息发送出现异常时，触发此方法。
     *
     * @param notificationBody 消息通知体
     * @param e 异常信息
     */
    default void invokeException(NotificationBody notificationBody, Exception e) {

    }
}
