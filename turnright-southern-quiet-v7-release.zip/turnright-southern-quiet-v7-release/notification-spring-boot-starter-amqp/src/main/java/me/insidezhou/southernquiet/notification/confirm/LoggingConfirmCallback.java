package me.insidezhou.southernquiet.notification.confirm;

import me.insidezhou.southernquiet.logging.SouthernQuietLogger;
import me.insidezhou.southernquiet.logging.SouthernQuietLoggerFactory;
import me.insidezhou.southernquiet.notification.driver.AmqpNotificationPublisher;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

/**
 * 日志输出的 ack 回掉实现
 *
 * @author maurice.chen
 */
public class LoggingConfirmCallback implements RabbitTemplate.ConfirmCallback{

    private final static SouthernQuietLogger LOGGER = SouthernQuietLoggerFactory.getLogger(AmqpNotificationPublisher.class);

    @Override
    public void confirm(CorrelationData correlationData, boolean ack, String cause) {
        LOGGER.message("接到publisher confirm")
                .context("correlationData", correlationData)
                .context("ack", ack)
                .context("cause", cause)
                .debug();

        if (!ack) {
            LOGGER.message("通知发送确认失败")
                    .context("correlationData", correlationData)
                    .context("cause", cause)
                    .warn();
        }
    }
}
