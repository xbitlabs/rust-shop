package me.insidezhou.southernquiet.notification.driver;

import com.rabbitmq.client.ConnectionFactory;
import me.insidezhou.southernquiet.amqp.rabbit.AbstractAmqpNotificationPublisher;
import me.insidezhou.southernquiet.amqp.rabbit.AmqpAutoConfiguration;
import me.insidezhou.southernquiet.logging.SouthernQuietLogger;
import me.insidezhou.southernquiet.logging.SouthernQuietLoggerFactory;
import me.insidezhou.southernquiet.notification.AmqpNotificationAutoConfiguration;
import me.insidezhou.southernquiet.notification.correlation.NotificationBody;
import me.insidezhou.southernquiet.notification.interceptor.AmqpNotificationInterceptor;
import org.springframework.amqp.core.MessageDeliveryMode;
import org.springframework.amqp.core.MessagePostProcessor;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionNameStrategy;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.connection.RabbitConnectionFactoryBean;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.SmartMessageConverter;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.amqp.RabbitProperties;
import org.springframework.context.Lifecycle;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.stream.Collectors;

@SuppressWarnings("WeakerAccess")
public class AmqpNotificationPublisher<N> extends AbstractAmqpNotificationPublisher<N> implements Lifecycle {

    private final static SouthernQuietLogger log = SouthernQuietLoggerFactory.getLogger(AmqpNotificationPublisher.class);

    private final Map<String, RabbitTemplate> virtualHostRabbitTemplateMap = new HashMap<>();
    private final Map<String, RabbitAdmin> multipleRabbitAdminMap = new HashMap<>();
    private final SmartMessageConverter messageConverter;
    private final AmqpNotificationAutoConfiguration.Properties notificationProperties;
    private final AmqpAutoConfiguration.Properties amqpProperties;
    private final RabbitProperties baseRabbitProperties;
    private final List<AmqpNotificationInterceptor> amqpNotificationInterceptors;

    private final boolean enablePublisherConfirm;

    public AmqpNotificationPublisher(
        SmartMessageConverter messageConverter,
        AmqpNotificationAutoConfiguration.Properties notificationProperties,
        AmqpAutoConfiguration.Properties properties,
        RabbitProperties rabbitProperties,
        Map<String, RabbitProperties> rabbitPropertiesMap,
        RabbitConnectionFactoryBean factoryBean,
        ObjectProvider<ConnectionNameStrategy> connectionNameStrategy,
        RabbitTemplate.ConfirmCallback confirmCallback,
        List<AmqpNotificationInterceptor> amqpNotificationInterceptors
    ) {
        this.messageConverter = messageConverter;
        this.notificationProperties = notificationProperties;
        this.amqpProperties = properties;
        this.baseRabbitProperties = rabbitProperties;
        this.enablePublisherConfirm = properties.isEnablePublisherConfirm() && null != confirmCallback;
        this.amqpNotificationInterceptors = amqpNotificationInterceptors;
        rabbitPropertiesMap.forEach((k, v) -> {
            if (ConnectionFactory.DEFAULT_HOST.equals(v.getHost()) || StringUtils.isEmpty(v.getHost())) {
                v.setHost(rabbitProperties.getHost());
            }
            if (v.getPort() == null) {
                v.setPort(rabbitProperties.getPort());
            }
            if (ConnectionFactory.DEFAULT_USER.equals(v.getUsername()) || StringUtils.isEmpty(v.getUsername())) {
                v.setUsername(rabbitProperties.getUsername());
            }
            if (ConnectionFactory.DEFAULT_PASS.equals(v.getPassword()) || StringUtils.isEmpty(v.getPassword())) {
                v.setPassword(rabbitProperties.getPassword());
            }
            if (StringUtils.isEmpty(v.getAddresses()) && !StringUtils.isEmpty(rabbitProperties.getAddresses())) {
                v.setAddresses(rabbitProperties.getAddresses());
            }

            RabbitTemplate rabbitTemplate = createRabbitTemplate(v, factoryBean, connectionNameStrategy, confirmCallback);
            virtualHostRabbitTemplateMap.put(v.getVirtualHost(), rabbitTemplate);
            multipleRabbitAdminMap.put(v.getVirtualHost(), new RabbitAdmin(rabbitTemplate));
        });

        RabbitTemplate baseRabbitTemplate = createRabbitTemplate(this.baseRabbitProperties, factoryBean, connectionNameStrategy, confirmCallback);
        virtualHostRabbitTemplateMap.put(this.baseRabbitProperties.getVirtualHost(), baseRabbitTemplate);

        RabbitAdmin baseRabbitAdmin = new RabbitAdmin(baseRabbitTemplate);
        multipleRabbitAdminMap.put(this.baseRabbitProperties.getVirtualHost(), baseRabbitAdmin);
    }

    private RabbitTemplate createRabbitTemplate(RabbitProperties rabbitProperties,
                                                RabbitConnectionFactoryBean factoryBean,
                                                ObjectProvider<ConnectionNameStrategy> connectionNameStrategy,
                                                RabbitTemplate.ConfirmCallback confirmCallback) {

        CachingConnectionFactory connectionFactory = AmqpAutoConfiguration.rabbitConnectionFactory(rabbitProperties, factoryBean, connectionNameStrategy);
        if (enablePublisherConfirm) {
            connectionFactory.setPublisherConfirmType(CachingConnectionFactory.ConfirmType.CORRELATED);
        }

        RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory);
        rabbitTemplate.setMessageConverter(messageConverter);

        if (enablePublisherConfirm) {
            rabbitTemplate.setConfirmCallback(confirmCallback);
        }

        return rabbitTemplate;
    }

    public SmartMessageConverter getMessageConverter() {
        return messageConverter;
    }


    @Override
    public void publish(N notification, int delay, String... virtualHosts) {
        publish(notification, delay, null, virtualHosts);
    }

    public void publish(N notification, int delay, CorrelationData correlationData, String... virtualHosts) {
        String prefix = notificationProperties.getNamePrefix();
        String source = getNotificationSource(notification.getClass());
        String routing = getRouting(prefix, source);
        String delayedRouting = getDelayRouting(prefix, source);

        NotificationBody notificationBody = new NotificationBody();

        notificationBody.setPrefix(prefix);
        notificationBody.setSource(source);
        notificationBody.setRouting(routing);
        notificationBody.setDelay(delay);
        notificationBody.setDelayedRouting(delayedRouting);
        notificationBody.setNotification(notification);

        if (AbstractNotificationListenerManager.isVirtualHostsNotEmpty(virtualHosts)) {
            notificationBody.setVirtualHosts(Arrays.asList(virtualHosts));
        }
        else {
            String virtualHost = baseRabbitProperties.getVirtualHost();
            List<String> values = Collections.singletonList(
                StringUtils.isEmpty(virtualHost) ? ConnectionFactory.DEFAULT_VHOST : virtualHost
            );
            notificationBody.setVirtualHosts(values);
        }

        Optional<AmqpNotificationInterceptor> optional = amqpNotificationInterceptors
            .stream()
            .filter(i -> i.isSupport(notificationBody))
            .findFirst();

        CorrelationData actualCorrelationData = correlationData;

        if (optional.isPresent()) {
            actualCorrelationData = optional.get().createCorrelationData(notificationBody);
        }

        notificationBody.setCorrelationData(actualCorrelationData);
        invoke(notificationBody);

    }

    public RabbitTemplate getRabbitTemplateByVirtualHost(String virtualHost) {
        RabbitTemplate rabbitTemplate = virtualHostRabbitTemplateMap.get(virtualHost);
        if (rabbitTemplate == null) {
            throw new IllegalArgumentException("找不到 [" + virtualHost + "] 的 virtualHost 配置");
        }
        return rabbitTemplate;
    }

    public RabbitAdmin getRabbitAdminByVirtualHost(String virtualHost) {
        RabbitAdmin rabbitAdmin = multipleRabbitAdminMap.get(virtualHost);
        Assert.notNull(rabbitAdmin, "找不到对应 [" + virtualHost + "] 的 RabbitAdmin 实现");

        return rabbitAdmin;
    }

    private void invoke(NotificationBody notificationBody) {

        MessagePostProcessor messagePostProcessor = message -> {
            MessageProperties properties = message.getMessageProperties();
            properties.setDeliveryMode(MessageDeliveryMode.PERSISTENT);

            if (notificationBody.getDelay() > 0) {
                properties.setDelay(notificationBody.getDelay());
            }

            return message;
        };

        Optional<AmqpNotificationInterceptor> interceptorOptional = amqpNotificationInterceptors
            .stream()
            .filter(i -> i.isSupport(notificationBody))
            .findFirst();

        try {

            List<RabbitTemplate> findTemplates = notificationBody
                .getVirtualHosts()
                .stream()
                .map(this::getRabbitTemplateByVirtualHost)
                .collect(Collectors.toList());

            if (findTemplates.size() != notificationBody.getVirtualHosts().size()) {
                throw new UnsupportedOperationException("通过 virtualHost 找到符合 rabbitmq 的模版数不相符");
            }

            String routing = notificationBody.getDelay() > 0 ?
                notificationBody.getDelayedRouting() :
                notificationBody.getRouting();

            if (enablePublisherConfirm) {
                findTemplates.forEach(
                    r -> r.invoke(operations -> {
                        operations.convertAndSend(
                            routing,
                            routing,
                            notificationBody.getNotification(),
                            messagePostProcessor,
                            notificationBody.getCorrelationData()
                        );

                        operations.waitForConfirmsOrDie(amqpProperties.getPublisherConfirmTimeout());
                        return null;
                    })
                );
            }
            else {
                findTemplates.forEach(r ->
                    r.convertAndSend(
                        routing,
                        routing,
                        notificationBody.getNotification(),
                        messagePostProcessor,
                        notificationBody.getCorrelationData()
                    )
                );
            }

            interceptorOptional.ifPresent(amqpNotificationInterceptor -> amqpNotificationInterceptor.invokeSuccess(notificationBody));
        }
        catch (Exception e) {
            log.message("发送MQ通知异常")
                .context("VirtualHosts", notificationBody.getVirtualHosts())
                .context("Routing", notificationBody.getRouting())
                .exception(e)
                .error();
            if (interceptorOptional.isPresent()) {
                interceptorOptional.get().invokeException(notificationBody, e);
            }
            else {
                throw e;
            }
        }
    }

    @Override
    public void start() {
        virtualHostRabbitTemplateMap.values().forEach(RabbitTemplate::start);
    }

    @Override
    public void stop() {
        virtualHostRabbitTemplateMap.values().forEach(RabbitTemplate::stop);
    }

    @Override
    public boolean isRunning() {
        return virtualHostRabbitTemplateMap.values().stream().allMatch(RabbitTemplate::isRunning);
    }

    public RabbitTemplate getBaseRabbitTemplate() {
        return getRabbitTemplateByVirtualHost(baseRabbitProperties.getVirtualHost());
    }

    public AmqpNotificationAutoConfiguration.Properties getNotificationProperties() {
        return notificationProperties;
    }

    public AmqpAutoConfiguration.Properties getAmqpProperties() {
        return amqpProperties;
    }

    public RabbitProperties getBaseRabbitProperties() {
        return baseRabbitProperties;
    }

    public RabbitAdmin getBaseRabbitAdmin() {
        return getRabbitAdminByVirtualHost(baseRabbitProperties.getVirtualHost());
    }

    public Map<String, RabbitTemplate> getVirtualHostRabbitTemplateMap() {
        return virtualHostRabbitTemplateMap;
    }
}
