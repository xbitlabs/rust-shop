package me.insidezhou.southernquiet.notification.driver;

import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;
import me.insidezhou.southernquiet.Constants;
import me.insidezhou.southernquiet.amqp.rabbit.AbstractAmqpNotificationPublisher;
import me.insidezhou.southernquiet.amqp.rabbit.AmqpMessageRecover;
import me.insidezhou.southernquiet.amqp.rabbit.DelayedMessage;
import me.insidezhou.southernquiet.amqp.rabbit.DirectRabbitListenerContainerFactoryConfigurer;
import me.insidezhou.southernquiet.logging.SouthernQuietLogger;
import me.insidezhou.southernquiet.logging.SouthernQuietLoggerFactory;
import me.insidezhou.southernquiet.notification.NotificationListener;
import me.insidezhou.southernquiet.notification.Qos;
import me.insidezhou.southernquiet.util.Amplifier;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.annotation.RabbitListenerConfigurer;
import org.springframework.amqp.rabbit.config.DirectRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerEndpoint;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.listener.RabbitListenerEndpointRegistrar;
import org.springframework.amqp.rabbit.listener.api.ChannelAwareMessageListener;
import org.springframework.context.ApplicationContext;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.annotation.AnnotatedElementUtils;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.*;
import java.util.stream.Collectors;

public class AmqpNotificationListenerManager extends AbstractNotificationListenerManager implements RabbitListenerConfigurer {
    private final static SouthernQuietLogger log = SouthernQuietLoggerFactory.getLogger(AmqpNotificationListenerManager.class);

    private final List<ListenerEndpoint> listenerEndpoints = new ArrayList<>();
    private final Amplifier amplifier;
    private final AmqpNotificationPublisher<?> publisher;

    public AmqpNotificationListenerManager(AmqpNotificationPublisher<?> publisher,
                                           Amplifier amplifier,
                                           ApplicationContext applicationContext
    ) {
        super(applicationContext);
        this.publisher = publisher;
        this.amplifier = amplifier;
    }

    @Override
    public void configureRabbitListeners(RabbitListenerEndpointRegistrar registrar) {
        super.initAllListeners();

        listenerEndpoints
            .stream()
            .collect(Collectors.groupingBy(ListenerEndpoint::getRouting))
            .values()
            .stream()
            .flatMap(Collection::stream)
            .forEach(endpoint -> {
                NotificationListener notificationListener = endpoint.getListenerAnnotation();

                if (isVirtualHostsNotEmpty(notificationListener.virtualHosts())) {
                    Arrays.stream(notificationListener.virtualHosts()).forEach(v -> {
                        RabbitTemplate rabbitTemplate = publisher.getRabbitTemplateByVirtualHost(v);
                        RabbitAdmin rabbitAdmin = publisher.getRabbitAdminByVirtualHost(v);
                        registerEndpoint(registrar, endpoint, rabbitTemplate, rabbitAdmin);
                    });
                }
                else {
                    registerEndpoint(registrar, endpoint, publisher.getBaseRabbitTemplate(), publisher.getBaseRabbitAdmin());
                }

            });
    }

    private void registerEndpoint(RabbitListenerEndpointRegistrar registrar,
                                  ListenerEndpoint endpoint,
                                  RabbitTemplate rabbitTemplate,
                                  RabbitAdmin rabbitAdmin) {
        String listenerName = endpoint.getListenerName();

        NotificationListener listenerAnnotation = endpoint.getListenerAnnotation();
        Amplifier amplifier = this.amplifier;

        if (!StringUtils.isEmpty(listenerAnnotation.amplifierBeanName())) {
            amplifier = applicationContext.getBean(listenerAnnotation.amplifierBeanName(), Amplifier.class);
        }

        DirectRabbitListenerContainerFactoryConfigurer containerFactoryConfigurer = new DirectRabbitListenerContainerFactoryConfigurer(
            publisher.getBaseRabbitProperties(),
            new AmqpMessageRecover(
                publisher.getBaseRabbitTemplate(),
                amplifier,
                Constants.AMQP_DEFAULT,
                getDeadRouting(publisher.getNotificationProperties().getNamePrefix(), listenerAnnotation, listenerName),
                AbstractAmqpNotificationPublisher.getDelayRouting(publisher.getNotificationProperties().getNamePrefix(), listenerAnnotation.notification()),
                getRetryRouting(publisher.getNotificationProperties().getNamePrefix(), listenerAnnotation, listenerName),
                publisher.getAmqpProperties()
            ),
            publisher.getAmqpProperties()
        );

        DirectRabbitListenerContainerFactory factory = new DirectRabbitListenerContainerFactory();
        factory.setMessageConverter(publisher.getMessageConverter());
        factory.setAcknowledgeMode(publisher.getAmqpProperties().getAcknowledgeMode());
        factory.setConsumersPerQueue(listenerAnnotation.concurrency());
        containerFactoryConfigurer.configure(factory, rabbitTemplate.getConnectionFactory());

        SimpleRabbitListenerEndpoint rabbitListenerEndpoint = new SimpleRabbitListenerEndpoint();
        rabbitListenerEndpoint.setId(UUID.randomUUID().toString());
        rabbitListenerEndpoint.setQueueNames(endpoint.getRouting());
        rabbitListenerEndpoint.setAdmin(rabbitAdmin);
        rabbitListenerEndpoint.setMessageListener(endpoint.getMessageListener());

        registrar.registerEndpoint(rabbitListenerEndpoint, factory);
    }

    @Override
    protected boolean initListener(NotificationListener listener, Object bean, Method method) {
        String listenerName = getListenerName(listener, method);
        String listenerRouting = getListenerRouting(listener, listenerName);

        //如果listenerEndpoints已经存在listenerRouting，则不继续创建了
        boolean isPresent = listenerEndpoints.stream()
            .anyMatch(endpoint -> listenerRouting.equals(endpoint.getRouting()));
        if (isPresent) {
            return false;
        }

        listenerEndpoints.stream()
            .filter(listenerEndpoint -> listener.notification() == listenerEndpoint.getListenerAnnotation().notification() && listenerName.equals(listenerEndpoint.getListenerName()) && Arrays.equals(listener.virtualHosts(), listenerEndpoint.getListenerAnnotation().virtualHosts()))
            .findAny()
            .ifPresent(listenerEndpoint -> {
                log.message("监听器重复")
                    .context(context -> {
                        context.put("queue", listenerRouting);
                        context.put("listener", bean.getClass().getName());
                        context.put("listenerName", listenerName);
                        if (isVirtualHostsNotEmpty(listener.virtualHosts())) {
                            context.put("virtualHosts", listener.virtualHosts());
                        }
                        context.put("notification", listener.notification().getSimpleName());
                    })
                    .warn();
                System.exit(-1);
            });

        declareExchangeAndQueue(listener, listenerName);

        DelayedMessage delayedAnnotation = AnnotatedElementUtils.findMergedAnnotation(listener.notification(), DelayedMessage.class);

        ListenerEndpoint listenerEndpoint = new ListenerEndpoint();
        listenerEndpoint.setListenerName(listenerName);
        listenerEndpoint.setListenerAnnotation(listener);
        listenerEndpoint.setRouting(listenerRouting);

        MessageListener messageListener = generateMessageListener(
            ParameterizedTypeReference.forType(listener.notification()),
            listenerRouting,
            listener,
            bean,
            method,
            listenerName,
            delayedAnnotation
        );
        listenerEndpoint.setMessageListener(messageListener);

        listenerEndpoints.add(listenerEndpoint);
        return true;
    }

    protected MessageListener generateMessageListener(ParameterizedTypeReference<?> typeReference,
                                                      String routing,
                                                      NotificationListener listener,
                                                      Object bean,
                                                      Method method,
                                                      String listenerName,
                                                      DelayedMessage delayedAnnotation
    ) {
        return (ChannelAwareMessageListener) (message, channel) -> {
            Qos qos = listener.qos();
            if (qos.prefetchSize() > 0 && !publisher.getAmqpProperties().getAcknowledgeMode().isAutoAck()) {

                channel.basicQos(qos.prefetchSize(), qos.prefetchCount(), qos.global());

                DefaultConsumer consumer = new DefaultConsumer(channel) {
                    @Override
                    public void handleDelivery(String consumerTag,
                                               Envelope envelope,
                                               AMQP.BasicProperties properties,
                                               byte[] body) throws IOException {
                        onMessageReceived(
                            message,
                            typeReference,
                            routing,
                            listener,
                            bean,
                            method,
                            listenerName,
                            delayedAnnotation
                        );
                        channel.basicAck(envelope.getDeliveryTag(), true);
                    }
                };

                channel.basicConsume(getListenerRouting(listener, listenerName), false, consumer);
            }
            else {
                onMessageReceived(
                    message,
                    typeReference,
                    routing,
                    listener,
                    bean,
                    method,
                    listenerName,
                    delayedAnnotation
                );
            }

        };
    }

    protected void onMessageReceived(Message message,
                                     ParameterizedTypeReference<?> typeReference,
                                     String routing,
                                     NotificationListener listener,
                                     Object bean,
                                     Method method,
                                     String listenerName,
                                     DelayedMessage delayedAnnotation) {
        Object notification = publisher.getMessageConverter().fromMessage(message, typeReference);

        onMessageReceived(routing, bean, listenerName, notification, message);

        Object[] parameters = Arrays.stream(method.getParameters())
            .map(parameter -> {
                Class<?> parameterClass = parameter.getType();

                if (parameterClass.isInstance(notification)) {
                    return notification;
                }
                else if (parameterClass.isInstance(listener)) {
                    return listener;
                }
                else if (parameterClass.equals(DelayedMessage.class)) {
                    return delayedAnnotation;
                }
                else {
                    log.message("不支持在通知监听器中使用此类型的参数")
                        .context("parameter", parameter.getClass())
                        .context("notification", listener.notification())
                        .warn();

                    try {
                        return parameterClass.getDeclaredConstructor().newInstance();
                    }
                    catch (Exception e) {
                        return null;
                    }
                }
            })
            .toArray();

        try {
            method.invoke(bean, parameters);
        }
        catch (RuntimeException e) {
            log.message("通知处理器抛出异常").exception(e).error();
            throw e;
        }
        catch (InvocationTargetException e) {
            Throwable target = e.getTargetException();

            log.message("通知处理器抛出异常").exception(target).error();

            if (target instanceof RuntimeException) {
                throw (RuntimeException) target;
            }

            throw new RuntimeException(target);
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    protected void onMessageReceived(
        String routing,
        Object bean,
        String listenerName,
        Object notification,
        Message message
    ) {
        log.message("收到通知")
            .context(context -> {
                context.put("queue", routing);
                context.put("listener", bean.getClass().getName());
                context.put("listenerName", listenerName);
                context.put("notification", notification.getClass().getSimpleName());
                context.put("message", message);
            })
            .debug();
    }

    public static String getDeadRouting(String prefix, NotificationListener listener, String listenerName) {
        return AbstractAmqpNotificationPublisher.getRouting(
            prefix,
            suffix("DEAD." + AbstractAmqpNotificationPublisher.getNotificationSource(listener.notification()), listenerName));
    }

    public static String getRetryRouting(String prefix, NotificationListener listener, String listenerName) {
        return AbstractAmqpNotificationPublisher.getRouting(
            prefix,
            suffix("RETRY." + AbstractAmqpNotificationPublisher.getNotificationSource(listener.notification()), listenerName));
    }

    private String getListenerRouting(NotificationListener listener, String listenerName) {
        return suffix(AbstractAmqpNotificationPublisher.getRouting(publisher.getNotificationProperties().getNamePrefix(), listener.notification()), listenerName);
    }

    private String getListenerName(NotificationListener listener, Method method) {
        String listenerName = listener.name();
        if (StringUtils.isEmpty(listenerName)) {
            listenerName = method.getName();
        }

        Assert.hasText(listenerName, "监听器的名称不能为空");
        return listenerName;
    }

    public static String suffix(String routing, String listenerName) {
        return routing + "#" + listenerName;
    }

    private void declareExchangeAndQueue(NotificationListener listener, String listenerName) {
        if (isVirtualHostsNotEmpty(listener.virtualHosts())) {
            Arrays.stream(listener.virtualHosts()).forEach(v -> {
                RabbitAdmin rabbitAdmin = publisher.getRabbitAdminByVirtualHost(v);
                declareExchangeAndQueue(rabbitAdmin, listener, listenerName);
            });
        }
        else {
            declareExchangeAndQueue(publisher.getBaseRabbitAdmin(), listener, listenerName);
        }
    }

    private void declareExchangeAndQueue(AmqpAdmin amqpAdmin, NotificationListener listener, String listenerName) {
        String routing = AbstractAmqpNotificationPublisher.getRouting(
            publisher.getNotificationProperties().getNamePrefix(),
            listener.notification());
        String delayRouting = AbstractAmqpNotificationPublisher.getDelayRouting(
            publisher.getNotificationProperties().getNamePrefix(),
            listener.notification()
        );
        String listenerRouting = getListenerRouting(listener, listenerName);
        Exchange exchange = new FanoutExchange(routing, true, false);
        Queue queue = new Queue(listenerRouting);

        amqpAdmin.declareExchange(exchange);
        amqpAdmin.declareQueue(queue);
        amqpAdmin.declareBinding(BindingBuilder.bind(queue).to(exchange).with(listenerRouting).noargs());

        Map<String, Object> deadQueueArgs = new HashMap<>();
        deadQueueArgs.put(Constants.AMQP_DLX, Constants.AMQP_DEFAULT);
        deadQueueArgs.put(Constants.AMQP_DLK, queue.getName());

        String deadName = getDeadRouting(publisher.getNotificationProperties().getNamePrefix(), listener, listenerName);
        Queue deadRouting = new Queue(deadName, true, false, false, deadQueueArgs);
        amqpAdmin.declareQueue(deadRouting);

        Map<String, Object> exchangeArguments = new HashMap<>();
        exchangeArguments.put(Constants.AMQP_DELAYED_TYPE, "direct");
        Exchange delayExchange = new CustomExchange(
            delayRouting,
            Constants.AMQP_DELAYED_EXCHANGE,
            true,
            false,
            exchangeArguments
        );

        amqpAdmin.declareExchange(delayExchange);

        Map<String, Object> retryQueueArgs = new HashMap<>();
        retryQueueArgs.put(Constants.AMQP_DLX, Constants.AMQP_DEFAULT);
        retryQueueArgs.put(Constants.AMQP_DLK, queue.getName());
        retryQueueArgs.put(Constants.AMQP_MESSAGE_TTL, 0); //这里的硬编码是为了消息到达队列之后立即转发至相应的工作队列。下同。
        Queue retryQueue = new Queue(
            getRetryRouting(publisher.getNotificationProperties().getNamePrefix(), listener, listenerName),
            true,
            false,
            false,
            retryQueueArgs
        );
        amqpAdmin.declareQueue(retryQueue);
        amqpAdmin.declareBinding(BindingBuilder.bind(retryQueue).to(delayExchange).with(retryQueue.getName()).noargs());

        Map<String, Object> delayQueueArgs = new HashMap<>();
        delayQueueArgs.put(Constants.AMQP_DLX, routing);
        delayQueueArgs.put(Constants.AMQP_DLK, routing);
        delayQueueArgs.put(Constants.AMQP_MESSAGE_TTL, 0);
        String delayName = AbstractAmqpNotificationPublisher.getDelayRouting(
            publisher.getNotificationProperties().getNamePrefix(),
            listener.notification()
        );
        Queue delayQueue = new Queue(
            delayName,
            true,
            false,
            false,
            delayQueueArgs
        );
        amqpAdmin.declareQueue(delayQueue);
        amqpAdmin.declareBinding(BindingBuilder.bind(delayQueue).to(delayExchange).with(delayQueue.getName()).noargs());
    }

    static class ListenerEndpoint {
        private NotificationListener listenerAnnotation;
        private String listenerName;
        private String routing;
        private MessageListener messageListener;

        public NotificationListener getListenerAnnotation() {
            return listenerAnnotation;
        }

        public void setListenerAnnotation(NotificationListener listenerAnnotation) {
            this.listenerAnnotation = listenerAnnotation;
        }

        public String getListenerName() {
            return listenerName;
        }

        public void setListenerName(String listenerName) {
            this.listenerName = listenerName;
        }

        public String getRouting() {
            return routing;
        }

        public void setRouting(String routing) {
            this.routing = routing;
        }

        public MessageListener getMessageListener() {
            return messageListener;
        }

        public void setMessageListener(MessageListener messageListener) {
            this.messageListener = messageListener;
        }
    }
}
