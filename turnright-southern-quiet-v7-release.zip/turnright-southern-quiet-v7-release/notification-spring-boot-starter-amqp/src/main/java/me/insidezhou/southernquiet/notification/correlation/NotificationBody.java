package me.insidezhou.southernquiet.notification.correlation;

import me.insidezhou.southernquiet.amqp.rabbit.MessageSource;
import org.springframework.amqp.rabbit.connection.CorrelationData;

import java.io.Serializable;
import java.util.List;

/**
 * 发布通知消息体
 *
 * @author chenxiaobo
 */
public class NotificationBody implements Serializable {

    private static final long serialVersionUID = -2130936748674686920L;

    /**
     * 通知内容
     */
    private Object notification;
    /**
     * rabbit 的相关数据
     */
    private CorrelationData correlationData;
    /**
     * 被通知的 virtualHosts 信息
     */
    private List<String> virtualHosts;
    /**
     * 前缀信息
     */
    private String prefix;
    /**
     * 来源
     *
     * @see MessageSource#source()
     */
    private String source;
    /**
     * 路由名称
     */
    private String routing;
    /**
     * 延迟路由名称
     */
    private String delayedRouting;
    /**
     * 延迟时间
     */
    private int delay;

    public NotificationBody() {
    }

    public Object getNotification() {
        return notification;
    }

    public void setNotification(Object notification) {
        this.notification = notification;
    }

    public CorrelationData getCorrelationData() {
        return correlationData;
    }

    public void setCorrelationData(CorrelationData correlationData) {
        this.correlationData = correlationData;
    }

    public List<String> getVirtualHosts() {
        return virtualHosts;
    }

    public void setVirtualHosts(List<String> virtualHosts) {
        this.virtualHosts = virtualHosts;
    }

    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getRouting() {
        return routing;
    }

    public void setRouting(String routing) {
        this.routing = routing;
    }

    public String getDelayedRouting() {
        return delayedRouting;
    }

    public void setDelayedRouting(String delayedRouting) {
        this.delayedRouting = delayedRouting;
    }

    public void setDelay(int delay) {
        this.delay = delay;
    }

    public int getDelay() {
        return delay;
    }
}
