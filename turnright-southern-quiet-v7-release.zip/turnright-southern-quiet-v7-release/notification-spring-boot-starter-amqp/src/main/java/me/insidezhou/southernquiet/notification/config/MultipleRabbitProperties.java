package me.insidezhou.southernquiet.notification.config;

import org.springframework.boot.autoconfigure.amqp.RabbitProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 多 rabbit mq 配置
 *
 * @author maurice.chen
 */
@ConfigurationProperties(prefix = "spring.rabbitmq")
public class MultipleRabbitProperties {

    /**
     * rabbitMq 配置 映射
     */
    private Map<String, RabbitProperties> multiple = new LinkedHashMap<>();

    /**
     * 多 rabbit mq 配置
     */
    public MultipleRabbitProperties() {
    }

    /**
     * 获取 rabbitMq 配置 映射
     *
     * @return rabbitMq 配置 映射
     */
    public Map<String, RabbitProperties> getMultiple() {
        return multiple;
    }

    /**
     * 设置 rabbitMq 配置 映射
     *
     * @param multiple rabbitMq 配置 映射
     */
    public void setMultiple(Map<String, RabbitProperties> multiple) {
        this.multiple = multiple;
    }
}
