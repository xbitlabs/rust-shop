package test.auth;

public interface SecurityService {
    void action();
}
