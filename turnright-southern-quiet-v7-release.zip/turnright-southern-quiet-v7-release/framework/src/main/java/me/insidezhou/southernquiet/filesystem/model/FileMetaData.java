package me.insidezhou.southernquiet.filesystem.model;

import java.io.Serializable;

/**
 * 文件元数据
 */
public class FileMetaData implements Serializable {
    private final static long serialVersionUID = 8826108912694997037L;
    /**
     * 新的文件名称
     */
    private String fileId;
    /**
     * 文件大小（B）
     */
    private Long fileSize;
    /**
     * 文件类型
     */
    private String mediaType;
    /**
     * 原文件名称
     */
    private String originalFileName;
    /**
     * 存入的OSS的文件夹
     */
    private String ossDir;
    /**
     * 文件路径，如果是存OSS的话，实际文件路径为 ossDir+path,如果是存本地则是 path
     */
    private String path;

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public Long getFileSize() {
        return fileSize;
    }

    public void setFileSize(Long fileSize) {
        this.fileSize = fileSize;
    }

    public String getMediaType() {
        return mediaType;
    }

    public void setMediaType(String mediaType) {
        this.mediaType = mediaType;
    }

    public String getOriginalFileName() {
        return originalFileName;
    }

    public void setOriginalFileName(String originalFileName) {
        this.originalFileName = originalFileName;
    }

    public String getOssDir() {
        return ossDir;
    }

    public void setOssDir(String ossDir) {
        this.ossDir = ossDir;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}
