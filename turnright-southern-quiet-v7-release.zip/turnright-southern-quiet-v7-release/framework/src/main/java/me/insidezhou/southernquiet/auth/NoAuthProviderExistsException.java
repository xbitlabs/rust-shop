package me.insidezhou.southernquiet.auth;

public class NoAuthProviderExistsException extends AuthException {}
