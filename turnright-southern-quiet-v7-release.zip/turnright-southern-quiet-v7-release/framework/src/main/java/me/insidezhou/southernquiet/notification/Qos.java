package me.insidezhou.southernquiet.notification;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 通知限流设置
 *
 * @author maurice.chen
 */
@Target({})
@Retention(RetentionPolicy.RUNTIME)
public @interface Qos {

    /**
     * 最多传输的内容的大小的限制，0 为不限制
     */
    int prefetchSize() default 0;

    /**
     * 一旦有N个消息还没有ack，则该消费者Consumer将阻塞block掉，直到有消息进行ack确认
     */
    int prefetchCount();

    /**
     * 是否将设置应用于 channel true 是，否则 false
     */
    boolean global() default false;
}
