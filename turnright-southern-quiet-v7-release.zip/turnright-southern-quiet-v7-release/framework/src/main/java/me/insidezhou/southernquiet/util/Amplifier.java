package me.insidezhou.southernquiet.util;

/**
 * 增幅器
 */
public interface Amplifier {
    /**
     * 增幅索引值。
     */
    long amplify(long index);
}
