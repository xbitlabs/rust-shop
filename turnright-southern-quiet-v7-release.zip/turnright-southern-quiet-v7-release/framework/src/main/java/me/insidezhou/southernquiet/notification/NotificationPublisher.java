package me.insidezhou.southernquiet.notification;

/**
 * 发布通知。
 */
public interface NotificationPublisher<N> {
    /**
     * 发布通知。
     *
     * @param notification 通知内容
     */
    default void publish(N notification) {
        publish(notification, 0);
    }

    /**
     * 发布通知
     *
     * @param notification 通知内容
     * @param virtualHosts 指定的 virtualHost 地址
     */
    default void publish(N notification, String... virtualHosts) {
        publish(notification, 0, virtualHosts);
    }

    /**
     * 在指定延迟后发布通知。
     *
     * @param notification 通知内容
     * @param delay 要延迟的时间，单位：毫秒。
     * @param virtualHosts 指定的 virtualHost 地址
     */
    void publish(N notification, int delay, String... virtualHosts);

}
